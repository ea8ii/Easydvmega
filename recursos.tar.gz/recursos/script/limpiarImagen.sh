#!/bin/bash

cp /opt/recursos/icons/Convencional.jpg /opt/recursos/icons/Convencional.jpg_texto.jpg
cp /opt/recursos/icons/Libre.jpg /opt/recursos/icons/Libre.jpg_texto.jpg
cp /opt/recursos/icons/Dmrplus.jpg /opt/recursos/icons/Dmrplus.jpg_texto.jpg
