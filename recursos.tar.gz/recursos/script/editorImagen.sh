#!/bin/bash

# VARIABLES

RIMAGEN="/opt/recursos/icons"
IMAGEN=$RIMAGEN/$1
TEXTO="Id DMR: "$2

# FIN VARIABLES

TEXTO()
{
	#La imagen
	#IMAGEN="$1"
	#El texto que le quiero añadir
	#TEXTO="$2"

	#Recupero dimensiones imagen
	DIMENSIONES=`identify -format "%wx%h" $IMAGEN`
	##echo "Dimensiones: $DIMENSIONES"
	x=`echo $DIMENSIONES | awk -F"x" '{print $1}'`
	y=`echo $DIMENSIONES | awk -F"x" '{print $2}'`
	##echo $x
	##echo $y

	# el limite sera el tamaño de 'Y' menos 30
	lim=$(($y-30))

	# y ya utilizo convert para generar la nueva imagen añadiendo un rectangulo negro, una linea blanca y el texto
	convert "$IMAGEN" -gravity SouthEast -font helvetica -pointsize 20 -fill black -draw "rectangle 0,$lim $x,$y" -fill white -draw "line 0,$lim $x,$lim" -draw "text 13 1 \"$TEXTO\"" ${IMAGEN}_texto.jpg
}
 
TEXTO $1
