#!/bin/bash

##
# VARIABLES
##
l
FOLDER=/opt/recursos/service
FOLDER2=/etc
FOLDER3=/opt/MMDVMHost/linux

FILE1=$FOLDER/convencional.ini
FILE2=$FOLDER/dmrplus.ini
FILE3=$FOLDER/libre.ini
FILE4=$FOLDER2/string
FILE5=$FOLDER/YSFGateway.ini

FILE_IMG1=Convencional.jpg
FILE_IMG2=Dmrplus.jpg
FILE_IMG3=Libre.jpg

ORIG_CALLSING='G9BF'
ORIG_ID='123456'
ORIG_IP='44.131.4.1'
ORIG_PASS='PASSWORD'
ORIG_MODO='Duplex=1'
ORIGRX='freqrx'
ORIGTX='freqtx'
ORIGLOC='Nowhere'
ORIG_CALLSING1='XX0XXX'
ORIG_CC='ColorCode=1'

##
# FIN VARIABLES
##

## RESET DE LOS INI ##

clear
/opt/recursos/service/reset

## Comienzo de reemplazos en los INI segun las entradas

function reemplazo (){
	sudo sed -i "s/$ORIG_CALLSING/$CALLSING/g" $FILE1
	sudo sed -i "s/$ORIG_CALLSING/$CALLSING/g" $FILE2
	sudo sed -i "s/$ORIG_CALLSING/$CALLSING/g" $FILE3
	sudo sed -i "s/$ORIG_CALLSING/$CALLSING/g" $FILE4
	sudo sed -i "s/$ORIG_CALLSING/$CALLSING/g" $FILE5


	sudo sed -i "s/$ORIG_ID/$DMRID/g" $FILE1
	sudo sed -i "s/$ORIG_ID/$DMRID/g" $FILE2
	sudo sed -i "s/$ORIG_ID/$DMRID/g" $FILE3
	sudo sed -i "s/$ORIG_ID/$DMRID/g" $FILE4

	
	sudo sed -i "s/$ORIG_IP/$IP/g" $FILE1
	sudo sed -i "s/$ORIG_IP/$IP/g" $FILE3	
	sudo sed -i "s/$ORIG_IP/$IP/g" $FILE4

	sudo sed -i "s/$ORIG_PASS/$PASS/g" $FILE1
	sudo sed -i "s/$ORIG_PASS/$PASS/g" $FILE3

	##	
	sudo sed -i "s/$ORIG_CC/ColorCode=$CC/g" $FILE1
	sudo sed -i "s/$ORIG_CC/ColorCode=$CC/g" $FILE2	
	sudo sed -i "s/$ORIG_CC/ColorCode=$CC/g" $FILE3
	###	
	
	sudo sed -i "s/$ORIGRX/$FREQRX/g" $FILE1
	sudo sed -i "s/$ORIGRX/$FREQRX/g" $FILE2
	sudo sed -i "s/$ORIGRX/$FREQRX/g" $FILE3        
	sudo sed -i "s/$ORIGRX/$FREQRX/g" $FILE4
	sudo sed -i "s/$ORIGRX/$FREQRX/g" $FILE5

	sudo sed -i "s/$ORIGTX/$FREQTX/g" $FILE1
	sudo sed -i "s/$ORIGTX/$FREQTX/g" $FILE2
	sudo sed -i "s/$ORIGTX/$FREQTX/g" $FILE3
	sudo sed -i "s/$ORIGTX/$FREQTX/g" $FILE4
	sudo sed -i "s/$ORIGTX/$FREQTX/g" $FILE5    

	sudo sed -i "s/$ORIGLOC/$LOC/g" $FILE1
	sudo sed -i "s/$ORIGLOC/$LOC/g" $FILE2
	sudo sed -i "s/$ORIGLOC/$LOC/g" $FILE3        
	sudo sed -i "s/$ORIGLOC/$LOC/g" $FILE4
	sudo sed -i "s/$ORIGLOC/$LOC/g" $FILE5
	
	}

function imagen (){
	/opt/recursos/script/editorImagen.sh $FILE_IMG1 $DMRID
	/opt/recursos/script/editorImagen.sh $FILE_IMG2 $DMRID
	/opt/recursos/script/editorImagen.sh $FILE_IMG3 $DMRID
	}

#####
echo "Parando Servicio MMDVMHost..."
echo ""
sleep 1
sudo systemctl stop mmdvmhost.service
clear
echo ""
echo "Bienvenido al configurador automatico de Identificador y DMR ID"
echo ""
echo ""

echo "Introduce tu indicativo:"
read CALLSING
clear

echo ""
echo ""
echo ""

echo "Introduce tu DMR ID:"
read DMRID
clear

echo ""
echo ""
echo ""

echo "Introduce el Codigo de Color (CC) que vas a utilizar. Por defecto suele ser 1:"
read CC
clear

echo ""
echo ""
echo ""

echo "Introduce la IP del MASTER DMR Brandmeister al que deseas conectarte:"
echo ""
echo "España ---> 84.232.5.113 "
echo "Mexico ---> 72.1.241.232"
echo "Panama ---> 45.33.8.38"
echo ""
read IP
clear

echo ""
echo ""
echo ""

echo "Introduce el password de acceso al MASTER DMR seleccionado. Por defecto es passw0rd"
echo "ojo!... que tiene un cero y además está todo en minúsculas"
echo ""
read PASS
clear

echo ""
echo ""
echo ""

##### Menu para duplex
/opt/recursos/script/duplex

echo "Introduce la frecuencia de Recepcion. Ej: 435100000    ... ojo, son 9 cifras...."
read FREQRX

echo ""
echo ""
echo ""

echo "Introduce la frecuencia de Transmision. Ej: 435100000 ... ojo, son 9 cifras...."
read FREQTX
clear

echo ""
echo ""
echo ""

echo "Introduce tu Ubicacion"
read LOC 

sleep 2
clear

##### Resumiendo los datos introducidos

echo ""
echo ""
echo " RESUMEN DE DATOS PARA CONFIGURAR:"
echo ""
echo ""
echo "Tu indicativo es:" $CALLSING 
echo "Tu Id es:" $DMRID
echo ""
echo "Te vas a conectar al master cuya IP es:" $IP "usando el password:" $PASS
echo ""
echo "Vas a utilizar las siguientes frecuencias: RX:" $FREQRX "TX:" $FREQTX
echo "Has elegido utilizar el ColoCode (CC):" $CC
echo ""
echo "Tu ubicación será:" $LOC
echo ""
echo ""
read -p "¿Es correcta esta información? (s/n)" SINO
echo ""
echo ""

#####
#####

case $SINO in 
[Ss]* ) 

	clear

	##### Configuracion de pantalla NEXTION u OLED
	/opt/recursos/script/pantalla
	clear
	##### Configuracion para usar FUSSION y DMR o solamente DMR
	/opt/recursos/script/fussion	
	clear 
	#### Configuracion de los comandos remotos	
	/opt/recursos/script/remotemenu
	sleep 3
	sudo systemctl stop mmdvmhost.service
	reemplazo
	imagen
	echo ""	
	echo "Configurando los ficheros INI para Modo Convencional, Libre y DMR Plus..."
	echo ""
	cp /opt/recursos/service/*.ini /home/pi/Pictures
	sudo cp /opt/recursos/service/YSFGateway.ini /opt/YSFClients/YSFGateway/YSFGateway.ini	
	sleep 3
	echo " Trabajo realizado con éxito... saliendo"
	sleep 3
	/usr/bin/pcmanfm -w /opt/recursos/icons/Convencional.jpg_texto.jpg
	cp /opt/recursos/icons/Convencional.jpg_texto.jpg /home/pi/Pictures
	cp /opt/recursos/icons/Dmrplus.jpg_texto.jpg /home/pi/Pictures
	cp /opt/recursos/icons/Libre.jpg_texto.jpg /home/pi/Pictures
	cp /opt/recursos/script/8iiremote.sh /home/pi/Pictures

	#sudo systemctl start mmdvmhost.service
	/opt/recursos/script/menu
	
;;	
[Nn]* ) 

	echo ""
	echo "Saliendo del script de configuración. Si necesitas configurar de nuevo, vuelve a ejecutarlo desde el menú."
	sleep 4
	;;
*) 

	echo ""
	echo "Has de escoger una opción, vuelve a ejercutar."
	sleep 4
	;;

esac

exit 0
