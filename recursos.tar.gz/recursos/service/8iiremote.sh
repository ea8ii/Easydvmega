#! /bin/bash

# tg_shutdown.sh - Automated shutdown and reboot on receipt of talkgroup
# Copyright (C) 2017  Tony Corbett, G0WFV and Stuart Scott, VK6LS
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USAp

# exit status ...
# 1 script not run as root
# 2 ini file doesn't exist

### CONFIG VARIABLES ###

# printenv
# echo "Wait"
# read test

# export DISPLAY=:0.0

sysopCallsign=EA8II
iniFile=/opt/recursos/service/convencional.ini
shutdownTG=90
rebootTG=80
WifiON=71
WifiOFF=70
Convencional=60
Libre=50
Dmrplus=40
Prueba=30
nogps=20
gps=25
db=10
allowShutdown=1
allowReboot=1

### DON'T EDIT BELOW HERE ###

# exit if we're not root ...
# [[ $EUID -ne 0 ]] && exit 1

# exit if we can't find the ini file
[[ -f $iniFile ]] || exit 2

# process the inifile and convert to variables ...
# 
# [Foo]
# Bar=Baz
#
# ... becomes the variable $FooBar with the value "Baz"
# (NOTE: spaces in section headers are replaced by underscores)
#
# a real life example ...
# 
# [General]
# Callsign=G0WFV
#
# ... becomes the variable $GeneralCallsign with the value "G0WFV"

foo=$(
	cat $iniFile | while read line
	do
		if echo $line | grep '^#.*$' >/dev/null # comment line
		then
			# Ignore!
			continue
		elif echo $line | grep '^$' >/dev/null # blank line
		then
			# Ignore!
			continue
		elif echo $line | grep '^\[.*\]$' >/dev/null # [Section Header]
		then
			iniSection=$(echo $line | sed 's/^\[\(.*\)\]$/\1/' | sed 's/[ -]//g')
		elif echo $line | grep '^.*=.*$' >/dev/null # Key=Value pair
		then
			iniKey=$(echo $line | sed 's/\(.*\)=.*$/\1/')
			iniValue=$(echo $line | sed 's/.*=\(.*\)$/\1/')
			echo $iniSection$iniKey=\"$iniValue\" # print the result in a specific format
		else # hopefully we'll never get here, but you never know!
			continue
		fi
	done
) 
eval $foo

# fix filepath if it doesn't end with a /
[[ "$(echo ${LogFilePath: -1})" != "/" ]] && LogFilePath="$LogFilePath/"

currentDate=foo # dummy current date variable to kick off the 1st tail!
shuttingDown=0

while true # main outer loop (run this forever!)
do
	checkDate=$(date -u +%Y-%m-%d)
	if [ "$checkDate" != "$currentDate" ]
	then
		kill $tailPID 2>/dev/null
		currentDate=$checkDate
		logFile=$LogFilePath$LogFileRoot-$currentDate.log

		tail -n 0 -F $logFile | while read line # inner loop to tail the logfile
		do
			# only react to sysop callsign ...
			foo=$(echo $line | grep "received RF voice header from $sysopCallsign to ")
	
			if [ $? = 0 ]
			then
				#TG=$(echo $line | awk -F"to " '{print $2}' | sed -e 's/TG //g')
				TG=$(echo $line | rev | cut -d' ' -f1 | rev)				

				#FUNCION APAGAR RASPBERRY

				if [ $TG = $shutdownTG ] && [ $shuttingDown -eq 0 ] && [ $allowShutdown -eq 1 ]
				then
					echo " Comando remoto enviado por el SYSOP para APAGAR "
					zenity --info --text "Comando remoto enviado por el SYSOP \n\n ORDEN DE APAGAR " --timeout 7
					curl "http://www.findu.com/cgi-bin/sendmsg.cgi?fromcall=$sysopCallsign&tocall=$sysopCallsign-7&msg=Apagando%EasyDVmega"					
					sleep 2					
					sudo shutdown now					
			
				# FUNCION REINCIAR RASPBERRY

				elif [ $TG = $rebootTG ] && [ $shuttingDown -eq 0 ] && [ $allowReboot -eq 1 ]
				then
					echo " Comando remoto enviado por el SYSOP para REINICIAR "
					zenity --info --text "Comando remoto enviado por el SYSOP \n\n ORDEN DE REINICIAR " --timeout 7
					curl "http://www.findu.com/cgi-bin/sendmsg.cgi?fromcall=$sysopCallsign&tocall=$sysopCallsign-7&msg=Reiniciando+EasyDVmega"
					sleep 2
					sudo reboot					
					
				# FUNCION ENCENDER WIFI
	
				elif [ $TG = $WifiON ] && [ $shuttingDown -eq 0 ] && [ $allowReboot -eq 1 ]
				then
					echo " Comando remoto enviado por el SYSOP para ENCENDER EL WIFI "
					zenity --info --text "Comando remoto enviado por el SYSOP \n\n ORDEN DE ENCENDER EL WIFI " --timeout 7
					sudo rfkill unblock 0
					sleep 10
					curl "http://www.findu.com/cgi-bin/sendmsg.cgi?fromcall=$sysopCallsign&tocall=$sysopCallsign-7&msg=WIFI+Encendido"

				# FUNCION APAGAR WIFI
	
				elif [ $TG = $WifiOFF ] && [ $shuttingDown -eq 0 ] && [ $allowReboot -eq 1 ]
				then
					echo " Comando remoto enviado por el SYSOP para APAGAR EL WIFI "
					zenity --info --text "Comando remoto enviado por el SYSOP \n\n ORDN DE APAGAR EL WIFI " --timeout 7
					curl "http://www.findu.com/cgi-bin/sendmsg.cgi?fromcall=$sysopCallsign&tocall=$sysopCallsign-7&msg=Wifi+apagado"
					sleep 2
					sudo rfkill block 0
				
				# FUNCION CAMBIO A MODO CONVENCIONAL	
				
				elif [ $TG = $Convencional ] && [ $shuttingDown -eq 0 ] && [ $allowReboot -eq 1 ]
				then
					echo ""					
					echo " Comando remoto enviado por el SYSOP para CAMBIAR A MODO CONVENCIONAL"
					zenity --info --text "Comando remoto enviado por el SYSOP \n\n ORDEN DE CAMBIAR A MODO CONVENCIONAL" --timeout 7
					curl "http://www.findu.com/cgi-bin/sendmsg.cgi?fromcall=$sysopCallsign&tocall=$sysopCallsign-7&msg=Cambiando+a+Modo+Convencional"
					sleep 2

						# Operacion
					sudo systemctl stop mmdvmhost.service

					sudo rm /lib/systemd/system/mmdvmhost.service
					sudo rm /etc/systemd/system/mmdvmhost.service
					sudo rm /opt/MMDVMHost/MMDVM.ini

					sudo cp /opt/recursos/service/convencional.ini /opt/MMDVMHost/MMDVM.ini
					sudo cp /opt/recursos/service/convencional.service /lib/systemd/system/mmdvmhost.service
					sudo cp /lib/systemd/system/mmdvmhost.service /etc/systemd/system/mmdvmhost.service

					sudo systemctl daemon-reload
					 

						# Mensaje de salida
					echo "Operacion realizada..."
					#/usr/bin/pcmanfm -w /opt/recursos/icons/Convencional.jpg_texto.jpg
					sed -i "s/Dmrplus/Convencional/g" /home/pi/.config/pcmanfm/LXDE-pi/desktop-items-0.conf
					sed -i "s/Libre/Convencional/g" /home/pi/.config/pcmanfm/LXDE-pi/desktop-items-0.conf
					sudo reboot
					

				elif [ $TG = $Libre ] && [ $shuttingDown -eq 0 ] && [ $allowReboot -eq 1 ]
				then
					# FUNCION CAMBIO A MODO LIBRE

					echo ""					
					echo " Comando remoto enviado por el SYSOP para CAMBIAR A MODO LIBRE"
					zenity --info --text "Comando remoto enviado por el SYSOP \n\n ORDEN DE CAMBIAR A MODO LIBRE" --timeout 7
					curl "http://www.findu.com/cgi-bin/sendmsg.cgi?fromcall=$sysopCallsign&tocall=$sysopCallsign-7&msg=Cambiando+a+Modo+Libre"					
					sleep 2

						# Operacion
					sudo systemctl stop mmdvmhost.service

					sudo rm /lib/systemd/system/mmdvmhost.service
					sudo rm /etc/systemd/system/mmdvmhost.service
					sudo rm /opt/MMDVMHost/MMDVM.ini

					sudo cp /opt/recursos/service/libre.ini /opt/MMDVMHost/MMDVM.ini
					sudo cp /opt/recursos/service/libre.service /lib/systemd/system/mmdvmhost.service
					sudo cp /lib/systemd/system/mmdvmhost.service /etc/systemd/system/mmdvmhost.service

					sudo systemctl daemon-reload 
					
						# Mensaje de salida
					echo "Operacion completada con exito..."
					#/usr/bin/pcmanfm -w /opt/recursos/icons/Libre.jpg_texto.jpg
					sed -i "s/Dmrplus/Libre/g" /home/pi/.config/pcmanfm/LXDE-pi/desktop-items-0.conf
					sed -i "s/Convencional/Libre/g" /home/pi/.config/pcmanfm/LXDE-pi/desktop-items-0.conf
					sudo reboot
					
				# FUNCION CAMBIO A MODO DMR PLUS

				elif [ $TG = $Dmrplus ] && [ $shuttingDown -eq 0 ] && [ $allowReboot -eq 1 ]
				then
					echo ""					
					echo " Comando remoto enviado por el SYSOP para CAMBIAR A MODO DMR PLUS"
					zenity --info --text "Comando remoto enviado por el SYSOP \n\n ORDEN DE CAMBIAR A MODO DMR PLUS" --timeout 7
					curl "http://www.findu.com/cgi-bin/sendmsg.cgi?fromcall=$sysopCallsign&tocall=$sysopCallsign-7&msg=Cambiando+a+Modo+DMRplus"
					sleep 2

					# Operacion
				sudo systemctl stop mmdvmhost.service

				sudo rm /lib/systemd/system/mmdvmhost.service
				sudo rm /etc/systemd/system/mmdvmhost.service
				sudo rm /opt/MMDVMHost/MMDVM.ini

				sudo cp /opt/recursos/service/dmrplus.ini /opt/MMDVMHost/MMDVM.ini
				sudo cp /opt/recursos/service/dmrplus.service /lib/systemd/system/mmdvmhost.service
				sudo cp /lib/systemd/system/mmdvmhost.service /etc/systemd/system/mmdvmhost.service

				sudo systemctl daemon-reload 
				
					# Mensaje de salida
				echo "Operacion realizada con exito..."
				# /usr/bin/pcmanfm -w /opt/recursos/icons/Dmrplus.jpg_texto.jpg
				sed -i "s/Convencional/Dmrplus/g" /home/pi/.config/pcmanfm/LXDE-pi/desktop-items-0.conf
				sed -i "s/Libre/Dmrplus/g" /home/pi/.config/pcmanfm/LXDE-pi/desktop-items-0.conf
				sudo reboot
				
				################ PRUEBA COMANDOS ##### ################
		
				elif [ $TG = $Prueba ] && [ $shuttingDown -eq 0 ] && [ $allowReboot -eq 1 ]
				then
					echo ""					
					echo " Comando remoto enviado por el SYSOP para CHEQUEO DE SISTEMA REMOTO"
					zenity --info --text "Comando remoto enviado por el SYSOP para CHEQUEO DE SISTEMA REMOTO \n\n TG/ID 90 Apaga la Raspberry \n\n TG/ID 80 Reincia la Raspberry \n\n TG/ID 70 Apaga el WIFI de la Raspberry \n\n TG/ID 71 Enciende el WIFI de la Raspberry \n\n TG/ID 60 Cambia a Modo Convencional \n\n TG/ID 50 Cambia a Modo Libre \n\n TG/ID 40 Cambia a Modo DMR+ \n\n TG/ID 30 Chequea el estado de los comandos remotos y ayuda \n\n TG/ID 20 Parchea Walkies SIN GPS \n\n TG/ID 25 Parchea Walkies CON GPS \n\n TG/ID 10 Actualiza la base de datos DMR del walkie" --timeout 15
					curl "http://www.findu.com/cgi-bin/sendmsg.cgi?fromcall=$sysopCallsign&tocall=$sysopCallsign-7&msg=Comandos+remotos+EasyDVmega+operativos"


				################ ACTUALIZACION DE LA BASE DE DATOS DEL WALKIE #####################
		
				elif [ $TG = $db ] && [ $shuttingDown -eq 0 ] && [ $allowReboot -eq 1 ]
				then
					echo ""					
					echo " Comando remoto enviado por el SYSOP para ACTUALIZACION DE LA BASE DE DATOS DEL WALKIE"
					zenity --info --text "Comando remoto enviado por el SYSOP para ACTUALIZACION DE LA BASE DE DATOS DEL WALKIE" --timeout 7
					cd /opt/md380tools
					sudo make updatedb flashdb
					zenity --info --text "La base de datos ha sido actualizada con exito..." --timeout 10
					curl "http://www.findu.com/cgi-bin/sendmsg.cgi?fromcall=$sysopCallsign&tocall=$sysopCallsign-7&msg=Base+de+datos+DMR+actualizada"

				################ PARCHEO DE WALKIE SIN GPS  #####################
		
				elif [ $TG = $nogps ] && [ $shuttingDown -eq 0 ] && [ $allowReboot -eq 1 ]
				then
					echo ""					
					echo " Comando remoto enviado por el SYSOP para PARCHEAR WALKIE SIN GPS"
					zenity --info --text "Comando remoto enviado por el SYSOP para PARCHEAR WALKIE SIN GPS " --timeout 7
					zenity --info --text "PON EL WALKIE EN MODO DFU. EN 10 SG COMIENZO EL PARCHEO " --timeout 10
					cd /opt/md380tools
					sudo make clean
					sudo git pull
					sudo make flash
					zenity --info --text "El parcheo de tu walkie SIN GPS ha finalizado. Ya puedes apagarlo y encenderlo de nuevo... " --timeout 7

				################ PARCHEO DE WALKIE CON GPS  #####################
		
				elif [ $TG = $gps ] && [ $shuttingDown -eq 0 ] && [ $allowReboot -eq 1 ]
				then
					echo ""					
					echo " Comando remoto enviado por el SYSOP para PARCHEAR WALKIE CON GPS"
					zenity --info --text "Comando remoto enviado por el SYSOP para PARCHEAR WALKIE CON GPS " --timeout 7
					zenity --info --text "PON EL WALKIE EN MODO DFU. EN 10 SG COMIENZO EL PARCHEO " --timeout 15
					cd /opt/md380tools
					sudo make clean
					sudo git pull
					sudo make flash_S13
					zenity --info --text "El parcheo de tu walkie CON GPS ha finalizado. Ya puedes apagarlo y encenderlo de nuevo... " --timeout 7

				elif [ $shuttingDown -eq 1 ]
				then
					# cancel shutdown or reboot if sysop tx any TG in 1 min grace period ...
					shutdown -c && shuttingDown=0
				fi
			fi	
		done & 2>/dev/null # inner loop is run in background so we can periodically check if the date's changed
		tailPID=$(($! - 1)) # save the PID of the inner loop so we can kill it when the date rolls over
	fi
	sleep 1 # check every second for date rollover (reduces cpu load)
done
